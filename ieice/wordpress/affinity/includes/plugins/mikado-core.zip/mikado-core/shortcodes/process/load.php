<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/process/process-holder.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/process/process-item.php';
