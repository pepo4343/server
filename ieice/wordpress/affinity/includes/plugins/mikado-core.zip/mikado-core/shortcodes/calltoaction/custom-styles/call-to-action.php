<?php
/**
 * Custom styles for Call To Action shortcode
 * Hooks to affinity_mikado_style_dynamic hook
 */

//if (!function_exists('affinity_mikado_call_to_action_style')) {
//
//	function affinity_mikado_call_to_action_style()
//	{
//
//		if (affinity_mikado_options()->getOptionValue('option_value') !== '') {
//			echo affinity_mikado_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => affinity_mikado_filter_px(affinity_mikado_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('affinity_mikado_style_dynamic', 'affinity_mikado_call_to_action_style');
//
//}

?>