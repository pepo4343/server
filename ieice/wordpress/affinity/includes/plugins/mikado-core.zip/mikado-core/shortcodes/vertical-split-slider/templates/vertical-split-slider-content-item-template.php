<div class="mkd-vss-ms-section" <?php affinity_mikado_inline_style($content_style);?> <?php echo mkd_core_get_inline_attrs($content_data); ?>>
	<?php echo do_shortcode($content); ?>
</div>