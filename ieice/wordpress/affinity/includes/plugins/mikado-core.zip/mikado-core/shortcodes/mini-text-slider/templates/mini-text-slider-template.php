<div class="mkd-mini-text-slider">
    <div class="mkd-mts-inner">
        <?php echo do_shortcode($content); ?>
    </div>
</div>