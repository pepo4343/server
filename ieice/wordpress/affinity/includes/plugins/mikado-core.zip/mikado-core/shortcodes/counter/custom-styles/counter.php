<?php
/**
 * Custom styles for Counter shortcode
 * Hooks to affinity_mikado_style_dynamic hook
 */

//if (!function_exists('affinity_mikado_counter_style')) {
//
//	function affinity_mikado_counter_style()
//	{
//
//		if (affinity_mikado_options()->getOptionValue('option_value') !== '') {
//			echo affinity_mikado_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => affinity_mikado_filter_px(affinity_mikado_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('affinity_mikado_style_dynamic', 'affinity_mikado_counter_style');
//
//}

?>