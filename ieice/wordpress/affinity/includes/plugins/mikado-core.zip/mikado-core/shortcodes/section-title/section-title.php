<?php
namespace Affinity\Modules\Shortcodes\SectionTitle;

use Affinity\Modules\Shortcodes\Lib;

class SectionTitle implements Lib\ShortcodeInterface {
	private $base;

	/**
	 * SectionTitle constructor.
	 */
	public function __construct() {
		$this->base = 'mkd_section_title';

		add_action('vc_before_init', array($this, 'vcMap'));
	}


	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		vc_map(array(
			'name'                      => esc_html__('Section Title', 'mkd-core'),
			'base'                      => $this->base,
			'category'                  => esc_html__('by MIKADO', 'mkd-core'),
			'icon'                      => 'icon-wpb-section-title extended-custom-icon',
			'allowed_container_element' => 'vc_row',
			'params'                    => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__('Title', 'mkd-core'),
					'param_name'  => 'title',
					'value'       => '',
					'save_always' => true,
					'admin_label' => true,
					'description' => esc_html__('Enter title text', 'mkd-core')
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__('Size', 'mkd-core'),
					'param_name'  => 'title_size',
					'value'       => array(
						esc_html__('Large', 'mkd-core')  => 'large',
						esc_html__('Medium', 'mkd-core') => 'medium',
						esc_html__('Small', 'mkd-core')  => 'small',
					),
					'save_always' => true,
					'admin_label' => true,
					'description' => esc_html__('Choose one of predefined title sizes', 'mkd-core')
				),
				array(
					'type'        => 'colorpicker',
					'heading'     => esc_html__('Color', 'mkd-core'),
					'param_name'  => 'title_color',
					'value'       => '',
					'save_always' => true,
					'admin_label' => true,
					'description' => esc_html__('Choose color of your title', 'mkd-core')
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__('Text Align', 'mkd-core'),
					'param_name'  => 'title_text_align',
					'value'       => array(
						''                                  => '',
						esc_html__('Center', 'mkd-core') => 'center',
						esc_html__('Left', 'mkd-core')   => 'left',
						esc_html__('Right', 'mkd-core')  => 'right'
					),
					'save_always' => true,
					'admin_label' => true,
					'description' => esc_html__('Choose text align for title', 'mkd-core')
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__('Margin Bottom', 'mkd-core'),
					'param_name'  => 'margin_bottom',
					'value'       => '',
					'save_always' => true,
					'admin_label' => true,
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__('Width (%)', 'mkd-core'),
					'param_name'  => 'width',
					'description' => esc_html__('Adjust the width of section title in percentages. Ommit the unit', 'mkd-core'),
					'value'       => '',
					'save_always' => true,
					'admin_label' => true
				)
			)
		));
	}

	public function render($atts, $content = null) {
		$default_atts = array(
			'title'            => '',
			'title_size'       => 'large',
			'title_color'      => '',
			'title_text_align' => '',
			'margin_bottom'    => '',
			'width'            => ''
		);

		$params = shortcode_atts($default_atts, $atts);

		if ($params['title'] !== '') {
			$params['section_title_classes'] = array('mkd-section-title');

			if ($params['title_size'] !== '') {
				$params['section_title_classes'][] = 'mkd-section-title-' . $params['title_size'];
			}

			$params['section_title_styles'] = array();

			if ($params['title_color'] !== '') {
				$params['section_title_styles'][] = 'color: ' . $params['title_color'];
			}

			if ($params['title_text_align'] !== '') {
				$params['section_title_styles'][] = 'text-align: ' . $params['title_text_align'];

				$params['section_title_classes'][] = 'mkd-section-title-' . $params['title_text_align'];
			}

			if ($params['width'] !== '') {
				$params['section_title_styles'][] = 'width: ' . $params['width'] . '%';
			}


			if ($params['margin_bottom'] !== '') {
				$params['section_title_styles'][] = 'margin-bottom: ' . affinity_mikado_filter_px($params['margin_bottom']) . 'px';
			}

			$params['title_tag'] = $this->getTitleTag($params);

			return mkd_core_get_core_shortcode_template_part('templates/section-title-template', 'section-title', '', $params);
		}
	}

	private function getTitleTag($params) {
		switch ($params['title_size']) {
			case 'large':
				$titleTag = 'h1';
				break;
			case 'medium':
				$titleTag = 'h2';
				break;
			case 'small':
				$titleTag = 'h3';
				break;
			default:
				$titleTag = 'h1';
		}

		return $titleTag;
	}
}