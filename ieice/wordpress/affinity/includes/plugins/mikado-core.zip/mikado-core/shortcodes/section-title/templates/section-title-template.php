<div class="mkd-section-title-holder">
	<<?php echo esc_attr($title_tag); ?> <?php affinity_mikado_class_attribute($section_title_classes); ?> <?php affinity_mikado_inline_style($section_title_styles); ?>>
	<?php echo esc_html($title); ?>
</<?php echo esc_attr($title_tag); ?>>
</div>