<div <?php affinity_mikado_class_attribute($holder_classes); ?> <?php affinity_mikado_inline_style($styles); ?>>
	<div class="mkd-card-slider" <?php echo mkd_core_get_inline_attrs($data_attrs); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>