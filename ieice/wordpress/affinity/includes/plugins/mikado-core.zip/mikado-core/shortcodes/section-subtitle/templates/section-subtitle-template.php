<div <?php affinity_mikado_class_attribute($classes); ?> <?php affinity_mikado_inline_style($holder_styles); ?>>
	<p <?php affinity_mikado_inline_style($styles); ?> class="mkd-section-subtitle"><?php echo wp_kses_post($text); ?></p>
</div>