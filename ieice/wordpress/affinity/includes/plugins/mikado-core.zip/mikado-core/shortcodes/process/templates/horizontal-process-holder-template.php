<div <?php affinity_mikado_class_attribute($holder_classes); ?>>
	<div class="mkd-process-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>