<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/tab-slider/tab-slider.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/tab-slider/tab-slider-item.php';