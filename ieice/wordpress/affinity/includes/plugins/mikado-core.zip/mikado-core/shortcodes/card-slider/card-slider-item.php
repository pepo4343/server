<?php
namespace Affinity\Modules\Shortcodes\CardSliderItem;

use Affinity\Modules\Shortcodes\Lib\ShortcodeInterface;

/**
 * Class Card Slider Item
 */
class CardSliderItem implements ShortcodeInterface {
	/**
	 * @var string
	 */
	private $base;

	public function __construct() {
		$this->base = 'mkd_card_slider_item';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		vc_map(array(
			'name'                      => esc_html__('Card Slider Item', 'mkd-core'),
			'base'                      => $this->base,
			'category'                  => esc_html__('by MIKADO', 'mkd-core'),
			'as_child'                  => array('only' => 'mkd_card_slider'),
			'icon'                      => 'icon-wpb-card-slider-item extended-custom-icon',
			'allowed_container_element' => 'vc_row',
			'params'                    => array(
				array(
					'type'       => 'attach_image',
					'heading'    => esc_html__('Image', 'mkd-core'),
					'param_name' => 'image',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__('Title', 'mkd-core'),
					'param_name' => 'title'
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__('Title tag', 'mkd-core'),
					'param_name'  => 'title_tag',
					'value'       => array(
						'h3' => 'h3',
						'h4' => 'h4',
						'h5' => 'h5'
					),
					'save_always' => true,
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__('Title Font Family', 'mkd-core'),
					'param_name' => 'title_font_family'
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__('Subtitle', 'mkd-core'),
					'param_name' => 'subtitle'
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__('Text', 'mkd-core'),
					'param_name' => 'text'
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__('Link', 'mkd-core'),
					'param_name'  => 'link',
					'value'       => '',
					'admin_label' => true
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__('Link Text', 'mkd-core'),
					'param_name' => 'link_text',
					'dependency' => array(
						'element'   => 'link',
						'not_empty' => true
					)
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__('Target', 'mkd-core'),
					'param_name' => 'link_target',
					'value'      => array(
						''                                 => '',
						esc_html__('Self', 'mkd-core')  => '_self',
						esc_html__('Blank', 'mkd-core') => '_blank'
					),
					'dependency' => array(
						'element'   => 'link',
						'not_empty' => true
					),
				),
				array(
					'type'        => 'colorpicker',
					'heading'     => esc_html__('Link Color', 'mkd-core'),
					'param_name'  => 'color',
					'dependency'  => array(
						'element'   => 'link',
						'not_empty' => true
					),
					'admin_label' => true
				)
			)
		));

	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 *
	 * @return string
	 */
	public function render($atts, $content = null) {
		$default_atts = array(
			'image'             => '',
			'title'             => '',
			'title_tag'         => 'h3',
			'title_font_family' => '',
			'subtitle'          => '',
			'text'              => '',
			'link'              => '',
			'link_text'         => '',
			'link_target'       => '_self',
			'color'             => '',
		);

		$params = shortcode_atts($default_atts, $atts);
		$params['button_parameters'] = $this->getButtonParameters($params);
		$params['title_inline_styles'] = $this->getInlineStyles($params);

		return mkd_core_get_core_shortcode_template_part('templates/card-slide', 'card-slider', '', $params);
	}

	private function getButtonParameters($params) {
		$button_params_array = array();

		$button_params_array['type'] = 'underline';
		$button_params_array['custom_class'] = 'mkd-card-slider-link';

		if (!empty($params['link_text'])) {
			$button_params_array['text'] = $params['link_text'];
		}

		if (!empty($params['link'])) {
			$button_params_array['link'] = $params['link'];
		}

		if (!empty($params['target'])) {
			$button_params_array['target'] = $params['target'];
		}

		if (!empty($params['color'])) {
			$button_params_array['color'] = $params['color'];
		}

		return $button_params_array;
	}

	private function getInlineStyles($params) {
		$styles = array();

		if (!empty($params['title_font_family'])) {
			$styles[] = 'font-family: ' . $params['title_font_family'];
		}

		return $styles;
	}
}