<?php

if (!function_exists('affinity_mikado_get_button_html')) {
	/**
	 * Calls button shortcode with given parameters and returns it's output
	 *
	 * @param $params
	 *
	 * @return mixed|string
	 */
	function affinity_mikado_get_button_html($params) {
		if(affinity_mikado_core_installed()) {
            $button_html = affinity_mikado_execute_shortcode('mkd_button', $params);
            $button_html = str_replace("\n", '', $button_html);

            return $button_html;
        }
	}
}

if (!function_exists('affinity_mikado_get_btn_hover_animation_types')) {
	/**
	 * @param bool $empty_val
	 *
	 * @return array
	 */
	function affinity_mikado_get_btn_hover_animation_types($empty_val = false) {
		$types = array(
			'disable'         => esc_html__('Disable Animation', 'mkd-core'),
			'fill-from-top'   => esc_html__('Fill From Top', 'mkd-core'),
			'fill-from-left'  => esc_html__('Fill From Left', 'mkd-core'),
			'fill-from-right' => esc_html__('Fill From Right', 'mkd-core')
		);

		if ($empty_val) {
			$types = array_merge(array(
				'' => 'Default'
			), $types);
		}

		return $types;
	}
}

if (!function_exists('mkd_get_btn_types')) {
	function affinity_mikado_get_btn_types($empty_val = false) {
		$types = array(
			'outline'       => esc_html__('Outline', 'mkd-core'),
			'solid'         => esc_html__('Solid', 'mkd-core'),
			'white'         => esc_html__('White', 'mkd-core'),
			'white-outline' => esc_html__('White Outline', 'mkd-core'),
			'black'         => esc_html__('Black', 'mkd-core'),
			'underline'     => esc_html__('Underline', 'mkd-core')
		);

		if ($empty_val) {
			$types = array_merge(array(
				'' => 'Default'
			), $types);
		}

		return $types;
	}
}