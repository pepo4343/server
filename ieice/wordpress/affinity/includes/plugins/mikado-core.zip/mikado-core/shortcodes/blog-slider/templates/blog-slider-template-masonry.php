<div <?php affinity_mikado_class_attribute($holder_classes); ?> <?php echo mkd_core_get_inline_attrs($holder_data); ?>>
	<?php if ($query->have_posts()) : ?>
		<?php while ($query->have_posts()) :
			$query->the_post();

			affinity_mikado_get_post_format_html('masonry-slider');

		endwhile; ?>
		<?php wp_reset_postdata(); ?>
	<?php else: ?>
		<p><?php esc_html_e('No posts were found.', 'mkd-core'); ?></p>
	<?php endif; ?>
</div>