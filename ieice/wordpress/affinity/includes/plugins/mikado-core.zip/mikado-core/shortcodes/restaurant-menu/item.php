<?php
namespace Affinity\Modules\RestaurantItem;

use Affinity\Modules\Shortcodes\Lib\ShortcodeInterface;

class RestaurantItem implements ShortcodeInterface{
    private $base;

    function __construct() {
        $this->base = 'mkd_restaurant_item';
        add_action('vc_before_init', array($this, 'vcMap'));
    }
    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if(function_exists('vc_map')){
            vc_map(
                array(
                    'name' => esc_html__('Restaurant Item', 'mkd-core'),
                    'base' => $this->base,
                    'as_child' => array('only' => 'mkd_restaurant_menu'),
                    'category' => esc_html__('by MIKADO', 'mkd-core'),
                    'icon' => 'icon-wpb-restaurant-menu-item extended-custom-icon',
                    'params' =>	array(
                        array(
                            'type' => 'textfield',
                            'class' => '',
                            'heading' =>  esc_html__('Item Title','mkd-core'),
                            'param_name' => 'title',
                            'value' => '',
                            'description' => ''
                        ),
                        array(
                            'type'       => 'dropdown',
                            'heading'    =>  esc_html__('Title Tag','mkd-core'),
                            'param_name' => 'title_tag',
                            'value'      => array(
                                ''   => '',
                                'h2' => 'h2',
                                'h3' => 'h3',
                                'h4' => 'h4',
                                'h5' => 'h5',
                                'h6' => 'h6',
                            ),
                            'dependency' => array(
								'element' => 'title',
								'not_empty' => true
							)
                        ),
                        array(
                            'type' => 'textfield',
                            'class' => '',
                            'heading' => esc_html__( 'Currency','mkd-core'),
                            'param_name' => 'currency',
                            'value' => '',
                            'description' =>  esc_html__('Default is "$"','mkd-core'),
                        ),
                        array(
                            'type' => 'textfield',
                            'class' => '',
                            'heading' =>  esc_html__('Price','mkd-core'),
                            'param_name' => 'price',
                            'value' => '',
                            'description' => ''
                        ),
                        array(
                            'type' => 'textfield',
                            'class' => '',
                            'heading' =>  esc_html__('Old Price','mkd-core'),
                            'param_name' => 'old_price',
                            'value' => '',
                            'description' => ''
                        ),
                        array(
                            'type' => 'attach_image',
                            'class' => '',
                            'heading' => esc_html__( 'Item Image','mkd-core'),
                            'param_name' => 'item_image',
                            'value' => '',
                            'description' => ''
                        ),
                        array(
                            'type' => 'textfield',
                            'class' => '',
                            'heading' => esc_html__( 'Description','mkd-core'),
                            'param_name' => 'description',
                            'value' => '',
                            'description' => ''
                        ),
                        array(
                            'type'       => 'dropdown',
                            'heading'    =>  esc_html__('Number of Stars','mkd-core'),
                            'param_name' => 'number_of_stars',
                            'value'      => array(
                                '0'   => '0',
                                '1' => '1',
                                '2' => '2',
                                '3' => '3',
                                '4' => '4',
                                '5' => '5',
                            ),
                        ),
                        array(
                            'type'        => 'checkbox',
                            'heading'     => esc_html__('Mark Item as Recommended', 'mkd-core'),
                            'param_name'  => 'item_recommended',
                            'value'       => array( esc_html__('Recommended?','mkd-core' )=> 'yes'),
                            'description' => ''
                        )
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $args = array(
            'title' => '',
            'title_tag' => 'h4',
            'currency' => '$',
            'item_image' => '',
            'price' => '',
            'description' => '',
            'number_of_stars'=>'0',
            'item_recommended'=>'',
            'old_price'=>''
        );

        $params = shortcode_atts($args, $atts);
        $params['content'] = $content;
        $params['item_holder_classes'] = $this->getItemHolderClasses($params);

        $html = mkd_core_get_core_shortcode_template_part('templates/item-template', 'restaurant-menu', '', $params);

        return $html;

    }

    private function getItemHolderClasses($params){
        $classes = array('mkd-rstrnt-item');

        if($params['item_recommended'] == 'yes'){
            $classes [] = 'mkd-recommended-enabled';
        }

        return $classes;
    }
}
