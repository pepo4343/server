<?php

namespace Affinity\Modules\Shortcodes\AdvancedSlider;

use Affinity\Modules\Shortcodes\Lib\ShortcodeInterface;

/**
 * Class AdvancedSlider
 */
class AdvancedSlider implements ShortcodeInterface {
	/**
	 * @var string
	 */
	private $base;

	/**
	 * AdvancedSlider constructor.
	 */
	public function __construct() {
		$this->base = 'mkd_advanced_slider';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	/**
	 *
	 */
	public function vcMap() {
		vc_map(array(
			'name'                    => esc_html__('Advanced Slider Holder', 'mkd-core'),
			'base'                    => $this->base,
			'as_parent'               => array('only' => 'mkd_advanced_slider_item'),
			'content_element'         => true,
			'show_settings_on_create' => false,
			'category'                => esc_html__('by MIKADO', 'mkd-core'),
			'icon'                    => 'icon-wpb-advanced-slider extended-custom-icon',
			'js_view'                 => 'VcColumnView',

		));
	}

	/**
	 * @param array $atts
	 * @param null $content
	 *
	 * @return string
	 */
	public function render($atts, $content = null) {
		$default_attrs = array();
		$params = shortcode_atts($default_attrs, $atts);

		$params['content'] = $content;

		return mkd_core_get_core_shortcode_template_part('templates/advanced-slider-holder', 'advanced-slider', '', $params);
	}
}