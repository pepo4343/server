<?php
namespace Affinity\Modules\Shortcodes\PlaylistItem;

use Affinity\Modules\Shortcodes\Lib\ShortcodeInterface;

/**
 * Class Playlist Item
 */
class PlaylistItem implements ShortcodeInterface {
	/**
	 * @var string
	 */
	private $base;

	public function __construct() {
		$this->base = 'mkd_playlist_item';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	/**
	 * Returns base for shortcode
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		vc_map(array(
			'name'                      => esc_html__('Playlist Item', 'mkd-core'),
			'base'                      => $this->base,
			'category'                  => esc_html__('by MIKADO', 'mkd-core'),
			'as_child'                  => array('only' => 'mkd_playlist'),
			'icon'                      => 'icon-wpb-playlist-item extended-custom-icon',
			'allowed_container_element' => 'vc_row',
			'params'                    => array(
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__('Audio file', 'mkd-core'),
					'param_name' => 'audio_file',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__('Title', 'mkd-core'),
					'param_name' => 'title'
				)
			)
		));

	}

	/**
	 * Renders shortcodes HTML
	 *
	 * @param $atts array of shortcode params
	 * @param $content string shortcode content
	 *
	 * @return string
	 */
	public function render($atts, $content = null) {
		$default_atts = array(
			'audio_file' => '',
			'title'      => ''
		);

		$params = shortcode_atts($default_atts, $atts);

		$params['random_id'] = mt_rand(100000, 1000000);

		return mkd_core_get_core_shortcode_template_part('templates/playlist-item-template', 'playlist', '', $params);
	}


}