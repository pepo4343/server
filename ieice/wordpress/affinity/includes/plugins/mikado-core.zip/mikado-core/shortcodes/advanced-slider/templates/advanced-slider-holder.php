<div class="mkd-advanced-holder">
    <div class="mkd-advanced-header cards">

    </div>
    <div class="mkd-advanced-panes">
        <?php echo do_shortcode($content); ?>
    </div>
</div>