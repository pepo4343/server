<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/centered-slider/centered-slider.php';