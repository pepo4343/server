<li class="mkd-tab-slider-item">
    <div class="mkd-tab-slide-holder">
        <?php echo mkd_core_get_core_shortcode_template_part('templates/slide-content', 'tab-slider', '', array('content' => $content)); ?>
    </div>
</li>