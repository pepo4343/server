<?php
if (affinity_mikado_is_woocommerce_installed()) {
	include_once MIKADO_CORE_ABS_PATH . '/shortcodes/product-list/product-list.php';
}