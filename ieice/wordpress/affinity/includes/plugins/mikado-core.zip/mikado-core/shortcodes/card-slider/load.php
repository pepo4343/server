<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/card-slider/card-slider.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/card-slider/card-slider-item.php';