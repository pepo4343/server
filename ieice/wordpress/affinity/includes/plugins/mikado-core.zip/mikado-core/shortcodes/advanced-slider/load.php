<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/advanced-slider/advanced-slider.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/advanced-slider/advanced-slider-item.php';