<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/team/options-map/map.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/team/team.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/team/custom-styles/team.php';