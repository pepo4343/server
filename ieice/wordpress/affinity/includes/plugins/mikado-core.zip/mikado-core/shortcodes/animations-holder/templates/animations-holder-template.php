<div <?php affinity_mikado_class_attribute($class); ?> <?php echo mkd_core_get_inline_attrs($data); ?>>
	<div <?php affinity_mikado_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>