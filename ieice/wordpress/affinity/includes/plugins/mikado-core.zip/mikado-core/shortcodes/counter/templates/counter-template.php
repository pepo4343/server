<?php
/**
 * Counter shortcode template
 */
?>
<div <?php affinity_mikado_class_attribute($counter_classes); ?>>
	<span class="mkd-counter <?php echo esc_attr($type) ?>">
		<?php echo esc_attr($digit); ?>
	</span>

	<div class="mkd-counter-content">
		<h2 class="mkd-counter-title"> <?php echo esc_attr($title); ?> </h2>
		<?php if (!empty($text)) { ?>
			<p class="mkd-counter-text"><?php echo esc_html($text); ?></p>
		<?php } ?>
		<?php
		if (!empty($link) && !empty($link_text)) :
			echo affinity_mikado_get_button_html($button_parameters);
		endif;
		?>
	</div>
</div>