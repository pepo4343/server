<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/device-slider/device-slider.php';