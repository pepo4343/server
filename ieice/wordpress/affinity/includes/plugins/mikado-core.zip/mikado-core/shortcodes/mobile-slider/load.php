<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/mobile-slider/mobile-slider.php';