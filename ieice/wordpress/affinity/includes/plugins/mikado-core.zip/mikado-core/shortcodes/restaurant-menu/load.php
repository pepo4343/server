<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/restaurant-menu/menu.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/restaurant-menu/item.php';

