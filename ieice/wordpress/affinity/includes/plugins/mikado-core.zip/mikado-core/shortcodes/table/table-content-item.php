<?php
namespace Affinity\Modules\Shortcodes\TableContentItem;

use Affinity\Modules\Shortcodes\Lib\ShortcodeInterface;

class TableContentItem implements ShortcodeInterface {
	private $base;

	function __construct() {
		$this->base = 'mkd_table_content_item';
		add_action('vc_before_init', array($this, 'vcMap'));
	}

	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		vc_map(array(
			'name'      => esc_html__('Table Content Item', 'mkd-core'),
			'base'      => $this->base,
			'icon'      => 'icon-wpb-table-item-content extended-custom-icon',
			'category'  => esc_html__('by MIKADO', 'mkd-core'),
			'as_parent' => array('except' => 'vc_row'),
			'as_child'  => array('only' => 'mkd_table_item'),
			'content_element'         => true,
			'js_view'   => 'VcColumnView',
			'params'    => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__('Title', 'mkd-core'),
					'admin_label' => true,
					'param_name'  => 'table_content_item_title'
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__('Link', 'mkd-core'),
					'admin_label' => true,
					'param_name'  => 'table_content_item_link'
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__('Description', 'mkd-core'),
					'admin_label' => true,
					'param_name'  => 'table_content_item_desc'
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__('Mark as trending?', 'mkd-core'),
					'admin_label' => true,
					'save_always' => true,
					'value'       => array(
						esc_html__('No','mkd-core')  => 'no',
						esc_html__('Yes','mkd-core') =>  'yes'
					),
					'param_name'  => 'table_content_item_trending'
				)
			)
		));
	}

	public function render($atts, $content = null) {

		$args   = array(
			'table_content_item_title' => '',
			'table_content_item_link'   => '',
			'table_content_item_desc' => '',
			'table_content_item_trending' => ''
		);
		$params = shortcode_atts($args, $atts);
		extract($params);

		$params['item_classes'] = $this->getItemClasses($params);

		$params['content']       = $content;

		$html = mkd_core_get_core_shortcode_template_part('templates/table-content-item', 'table', '', $params);

		return $html;

	}

	private function getItemClasses($params){
		$classes = array('mkd-table-content-item-holder');

		if(isset($params['table_content_item_trending']) && $params['table_content_item_trending'] == 'yes'){
			$classes[] = 'mkd-table-content-trending';
		}

		return $classes;
	}

}
