<?php
namespace Affinity\Modules\Shortcodes\TabSlider;

use Affinity\Modules\Shortcodes\Lib\ShortcodeInterface;

class TabSlider implements ShortcodeInterface {
    private $base;

    public function __construct() {
        $this->base = 'mkd_tab_slider';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        vc_map(array(
            'name'                    => esc_html__('Tab Slider', 'mkd-core'),
            'base'                    => $this->base,
            'as_parent'               => array('only' => 'mkd_tab_slider_item'),
            'content_element'         => true,
            'show_settings_on_create' => false,
            'category'                => esc_html__('by MIKADO', 'mkd-core'),
            'icon'                    => 'icon-wpb-tab-slider extended-custom-icon',
            'js_view'                 => 'VcColumnView',
            'params'                  => array(
                array(
                    'type'       => 'dropdown',
                    'heading'    => esc_html__('Tabs Skin', 'mkd-core'),
                    'param_name' => 'skin',
                    'value'      => array(
                        ''                                 => '',
                        esc_html__('Light', 'mkd-core')  => 'light',
                        esc_html__('Dark', 'mkd-core') => 'dark'
                    )
                )
            )
        ));
    }

    public function render($atts, $content = null) {
        $default_atts = array(
            'skin' => ''
        );

        $params = shortcode_atts($default_atts, $atts);
        $params['content'] = $content;
        $params['classes'] = $this -> getHolderClasses($params);

        return mkd_core_get_core_shortcode_template_part('templates/tab-slider-holder', 'tab-slider', '', $params);
    }


    /**
     * Return additional classes
     *
     * @param $params
     *
     * @return array
     */
    private function getHolderClasses($params) {
        $classes = '';

        if($params['skin'] !== '') {
            $classes .= 'mkd-tab-slider-'.$params['skin'];
        }

        return $classes;

    }
}