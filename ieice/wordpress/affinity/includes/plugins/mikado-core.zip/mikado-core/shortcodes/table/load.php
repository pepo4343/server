<?php
require_once MIKADO_CORE_ABS_PATH.'/shortcodes/table/table-holder.php';
require_once MIKADO_CORE_ABS_PATH.'/shortcodes/table/table-item.php';
require_once MIKADO_CORE_ABS_PATH.'/shortcodes/table/table-content-item.php';