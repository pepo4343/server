<?php

if(affinity_mikado_contact_form_7_installed()) {
    include_once MIKADO_CORE_ABS_PATH.'/widgets/contactform7/contact-form-7.php';
}