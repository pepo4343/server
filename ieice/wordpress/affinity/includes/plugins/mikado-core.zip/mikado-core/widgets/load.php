<?php

if(!function_exists('affinity_mikado_load_widget_class')) {
    /**
     * Loades widget class file.
     *
     */
    function affinity_mikado_load_widget_class() {
        include_once 'widget-class.php';
    }

    add_action('affinity_mikado_before_options_map', 'affinity_mikado_load_widget_class',9);  //9 is because of the cf7 widget that is loaded from module
}

if(!function_exists('affinity_mikado_load_widgets')) {
    /**
     * Loades all widgets by going through all folders that are placed directly in widgets folder
     * and loads load.php file in each. Hooks to affinity_mikado_after_options_map action
     */
    function affinity_mikado_load_widgets() {

        foreach(glob(MIKADO_CORE_ABS_PATH.'/widgets/*/load.php') as $widget_load) {
            include_once $widget_load;
        }

        include_once MIKADO_CORE_ABS_PATH.'/widgets/widget-loader.php';
    }

    add_action('affinity_mikado_before_options_map', 'affinity_mikado_load_widgets');
}