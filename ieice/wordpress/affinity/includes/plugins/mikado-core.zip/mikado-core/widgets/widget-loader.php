<?php

if(!function_exists('affinity_mikado_register_widgets')) {

	function affinity_mikado_register_widgets() {

		$widgets = array(
			'AffinityMikadoLatestPosts',
			'AffinityMikadoSearchOpener',
			'AffinityMikadoSideAreaOpener',
			'AffinityMikadoStickySidebar',
			'AffinityMikadoSocialIconWidget',
			'AffinityMikadoSeparatorWidget',
			'AffinityMikadoCallToActionButton',
			'AffinityMikadoHtmlWidget',
			'AffinityMikadoInfoWidget'
		);

		foreach($widgets as $widget) {
			register_widget($widget);
		}
	}
}

add_action('widgets_init', 'affinity_mikado_register_widgets');