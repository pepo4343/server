<?php

class AffinityMikadoLatestPosts extends AffinityMikadoWidget {
	protected $params;

	public function __construct() {
		parent::__construct(
			'mkd_latest_posts_widget', // Base ID
			esc_html__('Mikado Latest Posts', 'mkd-core'), // Name
			array('description' => esc_html__('Display posts from your blog', 'mkd-core')) // Args
		);

		$this->setParams();
	}

	protected function setParams() {
		$this->params = array(
			array(
				'name'  => 'title',
				'type'  => 'textfield',
				'title' => esc_html__('Title', 'mkd-core')
			),
			array(
				'name'    => 'type',
				'type'    => 'dropdown',
				'title'   => esc_html__('Type', 'mkd-core'),
				'options' => array(
					'minimal'      => esc_html__('Minimal', 'mkd-core'),
					'image-in-box' => esc_html__('Image in box', 'mkd-core'),
					'simple' => esc_html__('Simple', 'mkd-core')
				)
			),
			array(
				'name'  => 'number_of_posts',
				'type'  => 'textfield',
				'title' => esc_html__('Number of posts', 'mkd-core')
			),
			array(
				'name'    => 'order_by',
				'type'    => 'dropdown',
				'title'   => esc_html__('Order By', 'mkd-core'),
				'options' => array(
					'title' => esc_html__('Title', 'mkd-core'),
					'date'  => esc_html__('Date', 'mkd-core')
				)
			),
			array(
				'name'    => 'order',
				'type'    => 'dropdown',
				'title'   => esc_html__('Order', 'mkd-core'),
				'options' => array(
					'ASC'  => esc_html__('ASC', 'mkd-core'),
					'DESC' => esc_html__('DESC', 'mkd-core')
				)
			),
			array(
				'name'    => 'image_size',
				'type'    => 'dropdown',
				'title'   => esc_html__('Image Size', 'mkd-core'),
				'options' => array(
					'original'  => esc_html__('Original', 'mkd-core'),
					'landscape' => esc_html__('Landscape', 'mkd-core'),
					'square'    => esc_html__('Square', 'mkd-core'),
					'custom'    => esc_html__('Custom', 'mkd-core')
				)
			),
			array(
				'name'  => 'custom_image_size',
				'type'  => 'textfield',
				'title' => esc_html__('Custom Image Size', 'mkd-core')
			),
			array(
				'name'  => 'category',
				'type'  => 'textfield',
				'title' => esc_html__('Category Slug', 'mkd-core'),
			),
			array(
				'name'  => 'text_length',
				'type'  => 'textfield',
				'title' => esc_html__('Number of characters', 'mkd-core'),
			),
			array(
				'name'    => 'title_tag',
				'type'    => 'dropdown',
				'title'   => esc_html__('Title Tag', 'mkd-core'),
				'options' => array(
					""   => "",
					"h2" => "h2",
					"h3" => "h3",
					"h4" => "h4",
					"h5" => "h5",
					"h6" => "h6"
				)
			)
		);
	}

	public function widget($args, $instance) {
		extract($args);

		//prepare variables
		$content = '';
		$params = array();

		//is instance empty?
		if (is_array($instance) && count($instance)) {
			//generate shortcode params
			foreach ($instance as $key => $value) {
				$params[$key] = $value;
			}
		}
		if (empty($params['title_tag'])) {
			$params['title_tag'] = 'h6';
		}
		echo '<div class="widget mkd-latest-posts-widget">';

		if (!empty($instance['title'])) {
			print $args['before_title'] . $instance['title'] . $args['after_title'];
		}

		echo affinity_mikado_execute_shortcode('mkd_blog_list', $params);

		echo '</div>'; //close mkd-latest-posts-widget
	}
}
