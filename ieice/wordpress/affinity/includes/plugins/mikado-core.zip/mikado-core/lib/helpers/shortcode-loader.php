<?php

namespace Affinity\Modules\Shortcodes\Lib;

use Affinity\Modules\CallToAction\CallToAction;
use Affinity\Modules\Counter\Countdown;
use Affinity\Modules\Counter\Counter;
use Affinity\Modules\ElementsHolder\ElementsHolder;
use Affinity\Modules\ElementsHolderItem\ElementsHolderItem;
use Affinity\Modules\GoogleMap\GoogleMap;
use Affinity\Modules\Separator\Separator;
use Affinity\Modules\PieCharts\PieChartBasic\PieChartBasic;
use Affinity\Modules\PieCharts\PieChartDoughnut\PieChartDoughnut;
use Affinity\Modules\PieCharts\PieChartDoughnut\PieChartPie;
use Affinity\Modules\PieCharts\PieChartWithIcon\PieChartWithIcon;
use Affinity\Modules\Shortcodes\AnimationsHolder\AnimationsHolder;
use Affinity\Modules\Shortcodes\BlogSlider\BlogSlider;
use Affinity\Modules\Shortcodes\CenteredSlider\CenteredSlider;
use Affinity\Modules\Shortcodes\ComparisonPricingTables\ComparisonPricingTable;
use Affinity\Modules\Shortcodes\ComparisonPricingTables\ComparisonPricingTablesHolder;
use Affinity\Modules\Shortcodes\HorizontalTimeline\HorizontalTimeline;
use Affinity\Modules\Shortcodes\HorizontalTimeline\HorizontalTimelineItem;
use Affinity\Modules\Shortcodes\Icon\Icon;
use Affinity\Modules\Shortcodes\IconProgressBar;
use Affinity\Modules\Shortcodes\ImageGallery\ImageGallery;
use Affinity\Modules\Shortcodes\InfoBox\InfoBox;
use Affinity\Modules\Shortcodes\Process\ProcessHolder;
use Affinity\Modules\Shortcodes\Process\ProcessItem;
use Affinity\Modules\Shortcodes\SectionSubtitle\SectionSubtitle;
use Affinity\Modules\Shortcodes\SectionTitle\SectionTitle;
use Affinity\Modules\Shortcodes\TeamSlider\TeamSlider;
use Affinity\Modules\Shortcodes\TeamSliderItem\TeamSliderItem;
use Affinity\Modules\Shortcodes\CardSlider\CardSlider;
use Affinity\Modules\Shortcodes\CardSliderItem\CardSliderItem;
use Affinity\Modules\Shortcodes\TwitterSlider\TwitterSlider;
use Affinity\Modules\Shortcodes\VerticalProgressBar\VerticalProgressBar;
use Affinity\Modules\Shortcodes\VerticalSplitSlider\VerticalSplitSlider;
use Affinity\Modules\Shortcodes\VerticalSplitSliderContentItem\VerticalSplitSliderContentItem;
use Affinity\Modules\Shortcodes\VerticalSplitSliderLeftPanel\VerticalSplitSliderLeftPanel;
use Affinity\Modules\Shortcodes\VerticalSplitSliderRightPanel\VerticalSplitSliderRightPanel;
use Affinity\Modules\Shortcodes\VideoBanner\VideoBanner;
use Affinity\Modules\Shortcodes\WorkingHours\WorkingHours;
use Affinity\Modules\ProductList\ProductList;
use Affinity\Modules\SocialShare\SocialShare;
use Affinity\Modules\Team\Team;
use Affinity\Modules\OrderedList\OrderedList;
use Affinity\Modules\UnorderedList\UnorderedList;
use Affinity\Modules\Message\Message;
use Affinity\Modules\ProgressBar\ProgressBar;
use Affinity\Modules\IconListItem\IconListItem;
use Affinity\Modules\Tabs\Tabs;
use Affinity\Modules\Tab\Tab;
use Affinity\Modules\Shortcodes\TabSlider\TabSlider;
use Affinity\Modules\Shortcodes\TabSlider\TabSliderItem;
use Affinity\Modules\PricingTables\PricingTables;
use Affinity\Modules\PricingTable\PricingTable;
use Affinity\Modules\PricingTablesWithIcon\PricingTablesWithIcon;
use Affinity\Modules\PricingTableWithIcon\PricingTableWithIcon;
use Affinity\Modules\Accordion\Accordion;
use Affinity\Modules\AccordionTab\AccordionTab;
use Affinity\Modules\BlogList\BlogList;
use Affinity\Modules\Shortcodes\Button\Button;
use Affinity\Modules\Blockquote\Blockquote;
use Affinity\Modules\CustomFont\CustomFont;
use Affinity\Modules\Highlight\Highlight;
use Affinity\Modules\VideoButton\VideoButton;
use Affinity\Modules\Dropcaps\Dropcaps;
use Affinity\Modules\Shortcodes\IconWithText\IconWithText;
use Affinity\Modules\Shortcodes\MiniTextSlider\MiniTextSlider;
use Affinity\Modules\Shortcodes\MiniTextSliderItem\MiniTextSliderItem;
use Affinity\Modules\ImageWithTextOver\ImageWithTextOver;
use Affinity\Modules\RestaurantMenu\RestaurantMenu;
use Affinity\Modules\RestaurantItem\RestaurantItem;
use Affinity\Modules\Shortcodes\Playlist\Playlist;
use Affinity\Modules\Shortcodes\PlaylistItem\PlaylistItem;
use Affinity\Modules\Shortcodes\DeviceSlider\DeviceSlider;
use Affinity\Modules\Shortcodes\MobileSlider\MobileSlider;
use Affinity\Modules\Shortcodes\TableHolder\TableHolder;
use Affinity\Modules\Shortcodes\TableItem\TableItem;
use Affinity\Modules\Shortcodes\TableContentItem\TableContentItem;
use Affinity\Modules\Shortcodes\CardsGallery\CardsGallery;
use Affinity\Modules\Shortcodes\AdvancedSlider\AdvancedSlider;
use Affinity\Modules\Shortcodes\AdvancedSliderItem\AdvancedSliderItem;
use Affinity\Modules\Shortcodes\ReservationForm\ReservationForm;

/**
 * Class ShortcodeLoader
 */
class ShortcodeLoader {
	/**
	 * @var private instance of current class
	 */
	private static $instance;
	/**
	 * @var array
	 */
	private $loadedShortcodes = array();

	/**
	 * Private constuct because of Singletone
	 */
	private function __construct() {
	}

	/**
	 * Private sleep because of Singletone
	 */
	private function __wakeup() {
	}

	/**
	 * Private clone because of Singletone
	 */
	private function __clone() {
	}

	/**
	 * Returns current instance of class
	 * @return ShortcodeLoader
	 */
	public static function getInstance() {
		if (self::$instance == null) {
			return new self;
		}

		return self::$instance;
	}

	/**
	 * Adds new shortcode. Object that it takes must implement ShortcodeInterface
	 *
	 * @param ShortcodeInterface $shortcode
	 */
	private function addShortcode(ShortcodeInterface $shortcode) {
		if (!array_key_exists($shortcode->getBase(), $this->loadedShortcodes)) {
			$this->loadedShortcodes[$shortcode->getBase()] = $shortcode;
		}
	}

	/**
	 * Adds all shortcodes.
	 *
	 * @see ShortcodeLoader::addShortcode()
	 */
	private function addShortcodes() {
		$this->addShortcode(new ElementsHolder());
		$this->addShortcode(new ElementsHolderItem());
		$this->addShortcode(new Team());
		$this->addShortcode(new TeamSlider());
		$this->addShortcode(new TeamSliderItem());
		$this->addShortcode(new Icon());
		$this->addShortcode(new CallToAction());
		$this->addShortcode(new OrderedList());
		$this->addShortcode(new UnorderedList());
		$this->addShortcode(new Message());
		$this->addShortcode(new Counter());
		$this->addShortcode(new Countdown());
		$this->addShortcode(new ProgressBar());
		$this->addShortcode(new IconListItem());
		$this->addShortcode(new Tabs());
		$this->addShortcode(new Tab());
		$this->addShortcode(new PricingTables());
		$this->addShortcode(new PricingTable());
		$this->addShortcode(new PricingTablesWithIcon());
		$this->addShortcode(new PricingTableWithIcon());
		$this->addShortcode(new PieChartBasic());
		$this->addShortcode(new PieChartPie());
		$this->addShortcode(new PieChartDoughnut());
		$this->addShortcode(new PieChartWithIcon());
		$this->addShortcode(new Accordion());
		$this->addShortcode(new AccordionTab());
		$this->addShortcode(new BlogList());
		$this->addShortcode(new Button());
		$this->addShortcode(new Blockquote());
		$this->addShortcode(new CustomFont());
		$this->addShortcode(new Highlight());
		$this->addShortcode(new ImageGallery());
		$this->addShortcode(new GoogleMap());
		$this->addShortcode(new Separator());
		$this->addShortcode(new VideoButton());
		$this->addShortcode(new Dropcaps());
		$this->addShortcode(new IconWithText());
		$this->addShortcode(new SocialShare());
		$this->addShortcode(new VideoBanner());
		$this->addShortcode(new AnimationsHolder());
		$this->addShortcode(new SectionTitle());
		$this->addShortcode(new SectionSubtitle());
		$this->addShortcode(new InfoBox());
		$this->addShortcode(new ProcessHolder());
		$this->addShortcode(new ProcessItem());
		$this->addShortcode(new ComparisonPricingTablesHolder());
		$this->addShortcode(new ComparisonPricingTable());
		$this->addShortcode(new HorizontalTimeline());
		$this->addShortcode(new HorizontalTimelineItem());
		$this->addShortcode(new VerticalProgressBar());
		$this->addShortcode(new IconProgressBar());
		$this->addShortcode(new WorkingHours());
		$this->addShortcode(new BlogSlider());
		$this->addShortcode(new TwitterSlider());
		$this->addShortcode(new CenteredSlider());
		$this->addShortcode(new VerticalSplitSlider());
		$this->addShortcode(new VerticalSplitSliderLeftPanel());
		$this->addShortcode(new VerticalSplitSliderRightPanel());
		$this->addShortcode(new VerticalSplitSliderContentItem());
		$this->addShortcode(new MiniTextSlider());
		$this->addShortcode(new MiniTextSliderItem());
		$this->addShortcode(new TabSlider());
		$this->addShortcode(new TabSliderItem());
		$this->addShortcode(new CardSlider());
		$this->addShortcode(new CardSliderItem());
		$this->addShortcode(new ImageWithTextOver());
		$this->addShortcode(new RestaurantMenu());
		$this->addShortcode(new RestaurantItem());
		$this->addShortcode(new Playlist());
		$this->addShortcode(new PlaylistItem());
		$this->addShortcode(new DeviceSlider());
		$this->addShortcode(new MobileSlider());
		$this->addShortcode(new TableHolder());
		$this->addShortcode(new TableItem());
		$this->addShortcode(new TableContentItem());
		$this->addShortcode(new CardsGallery());
		$this->addShortcode(new AdvancedSlider());
		$this->addShortcode(new AdvancedSliderItem());
		$this->addShortcode(new ReservationForm());
		if (affinity_mikado_is_woocommerce_installed()) {
			$this->addShortcode(new ProductList());
		}

	}

	/**
	 * Calls ShortcodeLoader::addShortcodes and than loops through added shortcodes and calls render method
	 * of each shortcode object
	 */
	public function load() {
		$this->addShortcodes();

		foreach ($this->loadedShortcodes as $shortcode) {
			add_shortcode($shortcode->getBase(), array($shortcode, 'render'));
		}

	}
}

$shortcodeLoader = ShortcodeLoader::getInstance();
$shortcodeLoader->load();